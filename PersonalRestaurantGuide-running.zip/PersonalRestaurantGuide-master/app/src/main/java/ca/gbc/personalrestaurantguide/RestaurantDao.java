package ca.gbc.personalrestaurantguide;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface RestaurantDao {

    // Insert a single restaurant
    @Insert
    void insert(Restaurant restaurant);

    // Insert multiple restaurants (for batch operations)
    @Insert
    void insertAll(List<Restaurant> restaurants);

    // Update a restaurant
    @Update
    void update(Restaurant restaurant);

    // Delete a specific restaurant
    @Delete
    void delete(Restaurant restaurant);

    // Search restaurants by name or tags
    @Query("SELECT * FROM restaurants WHERE name LIKE '%' || :name || '%' OR tags LIKE '%' || :tags || '%'")
    List<Restaurant> search(String name, String tags);

    // Retrieve all restaurants (synchronous for background thread usage)
    @Query("SELECT * FROM restaurants")
    List<Restaurant> getAllRestaurantsSync();

    // Retrieve all restaurants (LiveData for UI observation)
    @Query("SELECT * FROM restaurants")
    LiveData<List<Restaurant>> getAllRestaurants();

    // Get filtered restaurants based on rating, price, and cuisine
    @Query("SELECT * FROM restaurants WHERE rating >= :rating  LIKE '%' || '%'")
    LiveData<List<Restaurant>> getFilteredRestaurants(int rating);
}