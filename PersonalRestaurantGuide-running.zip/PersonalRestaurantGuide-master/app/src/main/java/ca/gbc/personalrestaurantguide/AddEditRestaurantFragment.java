package ca.gbc.personalrestaurantguide;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

public class AddEditRestaurantFragment extends Fragment {

    private RestaurantViewModel restaurantViewModel;
    private EditText nameEditText, addressEditText, phoneEditText, descriptionEditText, tagsEditText;
    private RatingBar ratingBar;
    private Button saveButton;
    private int restaurantId = -1;  // Used to track if we are editing an existing restaurant

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_edit_restaurant, container, false);

        // Initialize views
        nameEditText = view.findViewById(R.id.restaurantNameEditText);
        addressEditText = view.findViewById(R.id.addressEditText);
        phoneEditText = view.findViewById(R.id.phoneEditText);
        descriptionEditText = view.findViewById(R.id.descriptionEditText);
        tagsEditText = view.findViewById(R.id.tagsEditText);
        ratingBar = view.findViewById(R.id.ratingBar);
        saveButton = view.findViewById(R.id.saveButton);

        // Set up ViewModel
        restaurantViewModel = new ViewModelProvider(this).get(RestaurantViewModel.class);

        // Check if editing an existing restaurant
        if (getArguments() != null) {
            restaurantId = getArguments().getInt("restaurantId", -1);  // Check for restaurant ID

            // If restaurant ID is passed, we're in edit mode
            if (restaurantId != -1) {
                // Populate the form with the existing restaurant data
                nameEditText.setText(getArguments().getString("restaurantName", ""));
                addressEditText.setText(getArguments().getString("restaurantAddress", ""));
                phoneEditText.setText(getArguments().getString("restaurantPhone", ""));
                descriptionEditText.setText(getArguments().getString("restaurantDescription", ""));
                tagsEditText.setText(getArguments().getString("restaurantTags", ""));
                ratingBar.setRating(getArguments().getFloat("restaurantRating", 0));
            }
        }

        // Save button logic
        saveButton.setOnClickListener(v -> saveRestaurant());

        return view;
    }


    private void saveRestaurant() {
        // Get data from input fields
        String name = nameEditText.getText().toString();
        String address = addressEditText.getText().toString();
        String phone = phoneEditText.getText().toString();
        String description = descriptionEditText.getText().toString();
        String tags = tagsEditText.getText().toString();
        float rating = ratingBar.getRating();

        // Validate input
        if (name.trim().isEmpty() || address.trim().isEmpty()) {
            Toast.makeText(getActivity(), "Please insert a name and address", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create the Restaurant object
        Restaurant restaurant = new Restaurant(name, address, phone, description, tags, rating);

        // If editing, update the existing restaurant; otherwise, insert a new restaurant
        if (restaurantId != -1) {
            restaurant.setId(restaurantId);  // Set the ID if updating
            restaurantViewModel.update(restaurant);  // Use update method if updating
            Toast.makeText(getActivity(), "Restaurant updated", Toast.LENGTH_SHORT).show();
        } else {
            restaurantViewModel.insert(restaurant);  // Use insert method for new restaurant
            Toast.makeText(getActivity(), "Restaurant saved", Toast.LENGTH_SHORT).show();
        }
        // Navigate to MainActivity
        Intent intent = new Intent(getActivity(), MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Clear the back stack to avoid going back to the fragment
        startActivity(intent);

        // Optionally, finish the current activity to prevent the user from going back to this screen
        getActivity().finish();
    }
}
