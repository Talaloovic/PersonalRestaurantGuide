package ca.gbc.personalrestaurantguide;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RestaurantRepository {

    private RestaurantDao restaurantDao;
    private LiveData<List<Restaurant>> allRestaurants;
    private ExecutorService executorService;

    public RestaurantRepository(Application application) {
        // Initialize the Restaurant Database and DAO
        RestaurantDatabase database = RestaurantDatabase.getInstance(application);
        restaurantDao = database.restaurantDao();
        allRestaurants = restaurantDao.getAllRestaurants();  // LiveData for all restaurants
        executorService = Executors.newSingleThreadExecutor();  // Executor for background tasks
    }

    // Method to get all restaurants
    public LiveData<List<Restaurant>> getAllRestaurants() {
        return allRestaurants;
    }

    // Method to insert a restaurant
    public void insert(Restaurant restaurant) {
        executorService.execute(() -> restaurantDao.insert(restaurant));  // Execute insert in background thread
    }

    // Method to update a restaurant
    public void update(Restaurant restaurant) {
        executorService.execute(() -> restaurantDao.update(restaurant));  // Execute update in background thread
    }

    // Method to delete a restaurant
    public void delete(Restaurant restaurant) {
        executorService.execute(() -> restaurantDao.delete(restaurant));  // Execute delete in background thread
    }

    // Method to search restaurants by name or tags
    public List<Restaurant> search(String name, String tags) {
        return restaurantDao.search(name, tags);  // Return the result of search
    }

    // Add the filtering method to return filtered restaurants
    public LiveData<List<Restaurant>> getFilteredRestaurants(int rating) {
        return restaurantDao.getFilteredRestaurants(rating);  // Get filtered list from DAO
    }
}
