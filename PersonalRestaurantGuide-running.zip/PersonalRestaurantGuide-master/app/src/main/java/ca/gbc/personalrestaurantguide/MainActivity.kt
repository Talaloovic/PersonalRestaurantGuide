package ca.gbc.personalrestaurantguide

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//        if (savedInstanceState == null) {
//            supportFragmentManager.beginTransaction()
//                .replace(R.id.fragment_container, RestaurantListFragment(), RestaurantListFragment::class.java.simpleName)
//                .commit()
//        }
        // Initialize the database with default data if empty
        initializeDatabase()
    }

    // Inflate the menu in the app bar
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.drawer_menu, menu)
        return true
    }

    // Handle menu item clicks
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_search -> {
                Toast.makeText(this, "Search clicked", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.action_filter -> {
                // Check if the fragment is an instance of RestaurantListFragment
                val fragment = supportFragmentManager.findFragmentByTag(RestaurantListFragment::class.java.simpleName)
                if (fragment is RestaurantListFragment) {
                    fragment.showFilterDialog()  // Call showFilterDialog() from the fragment
                }
                true
            }
            R.id.action_favorites -> {
                Toast.makeText(this, "Favorites clicked", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.action_add_edit_restaurant -> {
                // Navigate to the Add/Edit Restaurant Fragment
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragment_container, AddEditRestaurantFragment())
                    .addToBackStack(null)
                    .commit()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    // Check and initialize the database with default data if empty
    private fun initializeDatabase() {
        lifecycleScope.launch {
            val restaurantDao = RestaurantDatabase.getInstance(this@MainActivity).restaurantDao()
            val restaurants = withContext(Dispatchers.IO) {
                restaurantDao.getAllRestaurantsSync() // Fetch all restaurants synchronously
            }

            if (restaurants.isEmpty()) {
                // Insert default data if the database is empty
                insertDefaultRestaurants(restaurantDao)
            }
        }
    }

    private suspend fun insertDefaultRestaurants(restaurantDao: RestaurantDao) {
        withContext(Dispatchers.IO) {
            val defaultRestaurants = listOf(
                Restaurant(
                    "Default Restaurant",
                    "123 Main Street",
                    "123-456-7890",
                    "A great place to eat",
                    "default",
                    4.5f,
                    37.77, // Latitude
                    -122.41 // Longitude
                ),
                Restaurant(
                    "Second Restaurant",
                    "456 Elm Street",
                    "987-654-3210",
                    "Another great spot for food",
                    "default",
                    4.0f,
                    40.71, // Latitude
                    -74.00 // Longitude
                )
            )
            restaurantDao.insertAll(defaultRestaurants)
        }

        withContext(Dispatchers.Main) {
            Toast.makeText(this@MainActivity, "Default restaurants added", Toast.LENGTH_SHORT)
                .show()
        }

    }


}

