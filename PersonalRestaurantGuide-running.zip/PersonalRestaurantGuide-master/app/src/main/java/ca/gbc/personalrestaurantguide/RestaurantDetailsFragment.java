package ca.gbc.personalrestaurantguide;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class RestaurantDetailsFragment extends Fragment {

    private TextView nameTextView;
    private TextView addressTextView;
    private TextView phoneTextView;
    private TextView descriptionTextView;
    private TextView restaurantRatingTextView;
    private TextView restaurantTagsTextView;
    private int restaurantId;
    private RestaurantViewModel restaurantViewModel; // Add ViewModel for deletion

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize ViewModel
        restaurantViewModel = new ViewModelProvider(requireActivity()).get(RestaurantViewModel.class);

        // Register a MenuProvider specific to this fragment
        requireActivity().addMenuProvider(new androidx.core.view.MenuProvider() {
            @Override
            public void onCreateMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {
                // Clear previous menu items to prevent appending
                menu.clear();
                // Inflate the menu specific to this fragment
                menuInflater.inflate(R.menu.menu_restaurant_details, menu);
            }

            @Override
            public boolean onMenuItemSelected(@NonNull MenuItem menuItem) {
                int itemId = menuItem.getItemId();

                if (itemId == R.id.action_edit_restaurant) {
                    // Pass the restaurant data to AddEditRestaurantFragment
                    Bundle bundle = new Bundle();
                    bundle.putString("restaurantName", nameTextView.getText().toString());
                    bundle.putString("restaurantAddress", addressTextView.getText().toString());
                    bundle.putString("restaurantPhone", phoneTextView.getText().toString());
                    bundle.putString("restaurantDescription", descriptionTextView.getText().toString());
                    bundle.putString("restaurantTags", restaurantTagsTextView.getText().toString());

                    // Subtract the "Rating: " text before converting the remaining part to a float
                    String ratingText = restaurantRatingTextView.getText().toString();
                    String ratingValue = ratingText.replace("Rating: ", "").trim(); // Remove "Rating: " and any extra spaces

                    float rating = 0.0f;
                    try {
                        rating = Float.parseFloat(ratingValue);
                    } catch (NumberFormatException e) {
                        rating = 0.0f; // Default rating if the parsing fails
                    }

                    // Now you can put the rating in the bundle
                    bundle.putFloat("restaurantRating", rating);
                    bundle.putInt("restaurantId", restaurantId);

                    AddEditRestaurantFragment fragment = new AddEditRestaurantFragment();
                    fragment.setArguments(bundle);

                    requireActivity().getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.fragment_container, fragment)
                            .addToBackStack(null)
                            .commit();
                    return true;
                } else if (itemId == R.id.action_delete_restaurant) {
                    showDeleteConfirmationDialog();
                    return true;
                } else {
                    return false;
                }
            }
        }, getViewLifecycleOwner());
    }

    // Delete confirmation dialog

    private void showDeleteConfirmationDialog() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Delete Restaurant")
                .setMessage("Are you sure you want to delete this restaurant?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    // Delete the restaurant
                    Restaurant restaurantToDelete = new Restaurant(
                            nameTextView.getText().toString(),
                            addressTextView.getText().toString(),
                            phoneTextView.getText().toString(),
                            descriptionTextView.getText().toString(),
                            restaurantTagsTextView.getText().toString(),
                            Float.parseFloat(restaurantRatingTextView.getText().toString().replace("Rating: ", "").trim()),
                            0.0, 0.0 // You can replace this with actual coordinates if needed
                    );
                    restaurantToDelete.setId(restaurantId);  // Set the ID of the restaurant to delete
                    restaurantViewModel.delete(restaurantToDelete);

                    // Show confirmation message
                    Toast.makeText(requireContext(), "Restaurant deleted", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(requireContext(), MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);  // Clear the back stack
                    startActivity(intent);

                    // Optionally, finish the current activity to ensure it is closed
                    getActivity().finish();
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_restaurant_details, container, false);

        // Initialize views
        nameTextView = rootView.findViewById(R.id.restaurantNameTextView);
        addressTextView = rootView.findViewById(R.id.restaurantAddressTextView);
        phoneTextView = rootView.findViewById(R.id.restaurantPhoneTextView);
        descriptionTextView = rootView.findViewById(R.id.restaurantDescriptionTextView);
        restaurantTagsTextView = rootView.findViewById(R.id.restaurantTagsTextView);
        restaurantRatingTextView = rootView.findViewById(R.id.restaurantRatingTextView);

        // Get arguments and display restaurant details
        if (getArguments() != null) {
            String name = getArguments().getString("restaurantName", "No name provided");
            String address = getArguments().getString("restaurantAddress", "No address provided");
            String phone = getArguments().getString("restaurantPhone", "No phone number provided");
            String description = getArguments().getString("restaurantDescription", "No description provided");
            Float rating = getArguments().getFloat("restaurantRating", 0.0f);
            String tags = getArguments().getString("restaurantTags", "No Tags provided");
            restaurantId = getArguments().getInt("restaurantId", 0);

            // Set the data to the respective TextViews
            nameTextView.setText(name);
            addressTextView.setText(address);
            phoneTextView.setText(phone);
            descriptionTextView.setText(description);
            restaurantRatingTextView.setText("Rating: " + rating);  // Set the rating
            restaurantTagsTextView.setText("Tags: " + tags);  // Set the tags
        }

        return rootView;
    }
}