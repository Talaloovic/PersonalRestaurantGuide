package ca.gbc.personalrestaurantguide;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RestaurantListFragment extends Fragment {

    private RestaurantViewModel restaurantViewModel;
    private RecyclerView recyclerView;
    private RestaurantListAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_restaurant_list, container, false);

        // Initialize RecyclerView
        recyclerView = rootView.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Initialize adapter and pass the item click listener
        adapter = new RestaurantListAdapter(new RestaurantListAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Restaurant restaurant) {
                // Create a bundle to pass the data to RestaurantDetailsFragment
                Bundle bundle = new Bundle();
                bundle.putString("restaurantName", restaurant.getName());
                bundle.putString("restaurantAddress", restaurant.getAddress());
                bundle.putString("restaurantPhone", restaurant.getPhone());
                bundle.putString("restaurantDescription", restaurant.getDescription());
                bundle.putDouble("restaurantLatitude", restaurant.getLatitude());
                bundle.putDouble("restaurantLongitude", restaurant.getLongitude());
                bundle.putFloat("restaurantRating", restaurant.getRating());
                bundle.putString("restaurantTags", restaurant.getTags());
                bundle.putInt("restaurantId", restaurant.getId());

                Navigation.findNavController(rootView).navigate(R.id.action_restaurantListFragment_to_restaurantDetailsFragment, bundle);

            }

        }
        );

        // Set the adapter to the RecyclerView
        recyclerView.setAdapter(adapter);

        // Initialize ViewModel
        restaurantViewModel = new ViewModelProvider(this).get(RestaurantViewModel.class);

        // Observe the data in the ViewModel and update the RecyclerView when the data changes
        restaurantViewModel.getAllRestaurants().observe(getViewLifecycleOwner(), new Observer<List<Restaurant>>() {
            @Override
            public void onChanged(List<Restaurant> restaurants) {
                // Update the RecyclerView with the new data
                adapter.setRestaurants(restaurants);
            }
        });
        return rootView;
    }
    public void showFilterDialog() {
        // Inflate the filter dialog layout
        LayoutInflater inflater = LayoutInflater.from(requireContext());
        View filterView = inflater.inflate(R.layout.dialog_filter, null);

        // Create the dialog
        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle("Filter Restaurants")
                .setView(filterView)
                .setCancelable(true)
                .create();

        // Initialize the views from the dialog layout
        SeekBar ratingSeekBar = filterView.findViewById(R.id.ratingSeekBar);
        TextView ratingValue = filterView.findViewById(R.id.ratingValue);
        Button filterButton = filterView.findViewById(R.id.filterButton);

        // Show the filter dialog
        dialog.show();

        // Update rating value text when SeekBar changes
        ratingSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                ratingValue.setText("Rating: " + progress);  // Update the rating display text
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Handle Filter button click
        filterButton.setOnClickListener(v -> {
            // Get the selected rating from SeekBar
            int selectedRating = ratingSeekBar.getProgress();

            // Call your filtering logic here based on the selected values
            filterRestaurants(selectedRating);

            // Close the dialog
            dialog.dismiss();
        });
    }

    // Implement the filtering logic for the rating filter
    private void filterRestaurants(int rating) {
        // Use the selected rating to filter the restaurants list
        restaurantViewModel.getFilteredRestaurants(rating).observe(getViewLifecycleOwner(), filteredRestaurants -> {
            // Update your RecyclerView or list with the filtered data
            adapter.setRestaurants(filteredRestaurants);
        });
    }

    // Implement the filtering logic
    private void filterRestaurants(int rating, int price, String cuisine) {
        // Use the selected values to filter the restaurants list
        restaurantViewModel.getFilteredRestaurants(rating).observe(getViewLifecycleOwner(), filteredRestaurants -> {
            // Update your RecyclerView or list with the filtered data
            adapter.setRestaurants(filteredRestaurants);
        });
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.drawer_menu, menu);  // Inflate your menu
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_filter) {
            // Call the showFilterDialog method when Filter is clicked
            showFilterDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
