package ca.gbc.personalrestaurantguide;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

// Define the database with the Restaurant entity and specify the version
@Database(entities = {Restaurant.class}, version = 1, exportSchema = false)
public abstract class RestaurantDatabase extends RoomDatabase {

    // Singleton instance to avoid multiple database instances
    private static volatile RestaurantDatabase instance;

    // Access point to the DAO
    public abstract RestaurantDao restaurantDao();

    // Singleton pattern to provide a single instance of the database
    public static synchronized RestaurantDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(
                            context.getApplicationContext(),
                            RestaurantDatabase.class,
                            "restaurant_database"
                    )
                    .fallbackToDestructiveMigration() // Handles schema changes by recreating the database
                    .build();
        }
        return instance;
    }
}
