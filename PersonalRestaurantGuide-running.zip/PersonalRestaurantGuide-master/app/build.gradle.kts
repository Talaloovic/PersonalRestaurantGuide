plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android") // For Kotlin support
    id("kotlin-kapt") // Enable kapt for annotation processing
}

android {
    namespace = "ca.gbc.personalrestaurantguide" // Match the package name in AndroidManifest.xml
    compileSdk = 34

    defaultConfig {
        applicationId = "ca.gbc.personalrestaurantguide"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures {
        compose = true // Enable Jetpack Compose
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.1" // Compatible with Kotlin 1.9.0
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    // Specify Java and Kotlin compatibility
    kotlinOptions {
        jvmTarget = "17" // Ensure compatibility with Java 17
    }
    java {
        toolchain {
            languageVersion.set(JavaLanguageVersion.of(17)) // Ensure Java 17 is used
        }
    }
}

dependencies {
    // Core Android libraries
    implementation("androidx.core:core-ktx:1.7.0")
    implementation("androidx.appcompat:appcompat:1.4.0")
    implementation("com.google.android.material:material:1.4.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.2")

    // Google Maps SDK for Android
    implementation("com.google.android.gms:play-services-maps:17.0.0")
    implementation(libs.androidx.core.ktx) // Referencing the version catalog
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom)) // BOM for Compose dependencies
    implementation(libs.androidx.material3)
    implementation(libs.androidx.ui.tooling.preview)
    // Room components (for database)
    implementation("androidx.room:room-runtime:2.4.0")
    implementation(libs.androidx.material3.android)
    implementation(libs.androidx.ui.tooling.preview.android)
    implementation(libs.androidx.navigation.compose)
    kapt("androidx.room:room-compiler:2.4.0") // Use kapt for Room compiler

    // ViewModel and LiveData components (for UI state management)
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.4.0")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.4.0")

    // Navigation components (for fragment navigation)
    implementation("androidx.navigation:navigation-fragment-ktx:2.4.0")
    implementation("androidx.navigation:navigation-ui-ktx:2.4.0")

    // Unit testing libraries
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.3")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.4.0")
}
